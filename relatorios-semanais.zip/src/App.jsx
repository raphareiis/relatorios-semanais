import React, { useState } from 'react'
import * as XLSX from 'xlsx'
import { Upload } from 'lucide-react'
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, Legend } from 'recharts'

export default function App() {
  const [data, setData] = useState([])
  const [columns, setColumns] = useState([])

  const handleFile = (e) => {
    const file = e.target.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (evt) => {
      const bstr = evt.target.result
      const wb = XLSX.read(bstr, { type: 'binary' })
      const wsname = wb.SheetNames[0]
      const ws = wb.Sheets[wsname]
      const jsonData = XLSX.utils.sheet_to_json(ws)
      setData(jsonData)
      setColumns(Object.keys(jsonData[0] || {}))
    }
    reader.readAsBinaryString(file)
  }

  return (
    <div className="min-h-screen p-6">
      <h1 className="text-2xl font-bold mb-4">📊 Relatórios Semanais</h1>

      <input type="file" accept=".xlsx,.xls" onChange={handleFile} className="mb-4" />

      {data.length > 0 && (
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-lg font-semibold mb-2">Prévia dos dados</h2>
          <table className="min-w-full border">
            <thead>
              <tr>
                {columns.map((col) => (
                  <th key={col} className="border px-2 py-1">{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.slice(0, 10).map((row, i) => (
                <tr key={i}>
                  {columns.map((col) => (
                    <td key={col} className="border px-2 py-1">{row[col]}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>

          {columns.length >= 2 && (
            <div className="mt-6">
              <h2 className="text-lg font-semibold mb-2">Gráfico automático</h2>
              <LineChart width={600} height={300} data={data}>
                <CartesianGrid stroke="#ccc" />
                <XAxis dataKey={columns[0]} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey={columns[1]} stroke="#8884d8" />
              </LineChart>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
